

#ifndef __ARCH_ARM_MACH_MSM_CLOCK_ALPHA_PLL_H
#define __ARCH_ARM_MACH_MSM_CLOCK_ALPHA_PLL_H

#include <linux/spinlock.h>
#include <linux/clk/msm-clk-provider.h>

struct alpha_pll_masks {
	u32 lock_mask;		
	u32 active_mask;	
	u32 update_mask;	
	u32 vco_mask;		
	u32 vco_shift;
	u32 alpha_en_mask;	
	u32 output_mask;	
	u32 post_div_mask;
	u32 cal_l_val_mask;

	u32 test_ctl_lo_mask;
	u32 test_ctl_hi_mask;
};

struct alpha_pll_vco_tbl {
	u32 vco_val;
	unsigned long min_freq;
	unsigned long max_freq;
};

#define VCO(a, b, c) { \
	.vco_val = a,\
	.min_freq = b,\
	.max_freq = c,\
}

struct alpha_pll_clk {
	struct alpha_pll_masks *masks;

	void *const __iomem *base;

	u32 offset;
	u32 fabia_frac_offset;

	
	u32 fsm_reg_offset;
	u32 fsm_en_mask;

	u32 enable_config;	
	u32 post_div_config;	
	u32 config_ctl_val;	
	u32 test_ctl_lo_val;	
	u32 test_ctl_hi_val;
	u32 cal_l_val;		

	struct alpha_pll_vco_tbl *vco_tbl;
	u32 num_vco;
	u32 current_vco_val;
	bool inited;
	bool slew;
	bool no_prepared_reconfig;

	
	bool dynamic_update;

	
	bool offline_bit_workaround;
	bool no_irq_dis;
	bool is_fabia;
	unsigned long min_supported_freq;
	struct clk c;
};

static inline struct alpha_pll_clk *to_alpha_pll_clk(struct clk *c)
{
	return container_of(c, struct alpha_pll_clk, c);
}


#endif
extern void __init_alpha_pll(struct clk *c);
extern const struct clk_ops clk_ops_alpha_pll;
extern const struct clk_ops clk_ops_alpha_pll_hwfsm;
extern const struct clk_ops clk_ops_fixed_alpha_pll;
extern const struct clk_ops clk_ops_dyna_alpha_pll;
extern const struct clk_ops clk_ops_fixed_fabia_alpha_pll;
extern const struct clk_ops clk_ops_fabia_alpha_pll;
