



#ifndef _MSM_DP_MST_SIM_H_
#define _MSM_DP_MST_SIM_H_

#include <linux/types.h>
#include <drm/drmP.h>
#include <drm/drm_dp_helper.h>


struct msm_dp_mst_sim_port {
	bool input;
	bool mcs;
	bool ddps;
	u8 pdt;
	bool ldps;
	u8 dpcd_rev;
	u8 peer_guid[16];
	u8 num_sdp_streams;
	u8 num_sdp_stream_sinks;
	u16 full_pbn;
	u16 avail_pbn;
	const u8 *edid;
	u32 edid_size;
};


struct msm_dp_mst_sim_cfg {
	void *host_dev;
	u8 guid[16];

	
	void (*host_hpd_irq)(void *host_dev);

	
	void (*host_req)(void *host_dev, const u8 *in, int in_size,
			u8 *out, int *out_size);
};


int msm_dp_mst_sim_create(const struct msm_dp_mst_sim_cfg *cfg,
		void **mst_sim_context);


int msm_dp_mst_sim_destroy(void *mst_sim_context);


int msm_dp_mst_sim_transfer(void *mst_sim_context, struct drm_dp_aux_msg *msg);


int msm_dp_mst_sim_update(void *mst_sim_context, u32 port_num,
		struct msm_dp_mst_sim_port *ports);

#endif 

