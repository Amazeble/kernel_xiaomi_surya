

#ifndef COMMAND_DB_H
#define COMMAND_DB_H


enum cmd_db_hw_type {
	CMD_DB_HW_MIN = 3,
	CMD_DB_HW_ARC = CMD_DB_HW_MIN,
	CMD_DB_HW_VRM = 4,
	CMD_DB_HW_BCM = 5,
	CMD_DB_HW_MAX = CMD_DB_HW_BCM,
	CMD_DB_HW_ALL = 0xff,
};
#ifdef CONFIG_QCOM_COMMAND_DB

u32 cmd_db_get_addr(const char *resource_id);


bool cmd_db_get_priority(u32 addr, u8 drv_id);


int cmd_db_get_aux_data(const char *resource_id, u8 *data, int len);


int cmd_db_get_aux_data_len(const char *resource_id);


u16 cmd_db_get_version(const char *resource_id);


int cmd_db_ready(void);


int cmd_db_get_slave_id(const char *resource_id);


int cmd_db_is_standalone(void);
#else

static inline u32 cmd_db_get_addr(const char *resource_id)
{
	return 0;
}

bool cmd_db_get_priority(u32 addr, u8 drv_id)
{
	return false;
}

int cmd_db_get_aux_data(const char *resource_id, u8 *data, int len)
{
	return -ENODEV;
}

int cmd_db_get_aux_data_len(const char *resource_id)
{
	return -ENODEV;
}

u16 cmd_db_get_version(const char *resource_id)
{
	return 0;
}

int cmd_db_ready(void)
{
	return -ENODEV;
}

int cmd_db_get_slave_id(const char *resource_id)
{
	return -ENODEV;
}

int cmd_db_is_standalone(void)
{
	return -ENODEV;
}
#endif
#endif
