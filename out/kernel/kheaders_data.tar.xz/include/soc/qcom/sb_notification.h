

#ifndef _SB_NOTIFICATION_H
#define _SB_NOTIFICATION_H


#define EVENT_REQUEST_WAKE_UP 0x01

#ifdef CONFIG_QTI_NOTIFY_SIDEBAND

int sb_register_evt_listener(struct notifier_block *nb);


int sb_unregister_evt_listener(struct notifier_block *nb);


int sb_notifier_call_chain(unsigned long val, void *v);

#else
static inline int sb_register_evt_listener(struct notifier_block *nb)
{
	return -EINVAL;
}
static inline int sb_unregister_evt_listener(struct notifier_block *nb)
{
	return -EINVAL;
}
static inline int sb_notifier_call_chain(unsigned long val, void *v)
{
	return -EINVAL;
}
#endif 

#endif 
