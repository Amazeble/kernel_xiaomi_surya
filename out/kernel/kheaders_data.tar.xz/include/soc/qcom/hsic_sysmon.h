

#ifndef __HSIC_SYSMON_H__
#define __HSIC_SYSMON_H__


enum hsic_sysmon_device_id {
	HSIC_SYSMON_DEV_EXT_MODEM,
	HSIC_SYSMON_DEV_EXT_MODEM_2,
	NUM_HSIC_SYSMON_DEVS
};

#if IS_ENABLED(CONFIG_MSM_HSIC_SYSMON) || \
	IS_ENABLED(CONFIG_MSM_HSIC_SYSMON_MODULE)

extern int hsic_sysmon_open(enum hsic_sysmon_device_id id);
extern void hsic_sysmon_close(enum hsic_sysmon_device_id id);
extern int hsic_sysmon_read(enum hsic_sysmon_device_id id, char *data,
			    size_t len, size_t *actual_len, int timeout);
extern int hsic_sysmon_write(enum hsic_sysmon_device_id id, const char *data,
			     size_t len, int timeout);

#else 

static inline int hsic_sysmon_open(enum hsic_sysmon_device_id id)
{
	return -ENODEV;
}

static inline void hsic_sysmon_close(enum hsic_sysmon_device_id id) { }

static inline int hsic_sysmon_read(enum hsic_sysmon_device_id id, char *data,
				   size_t len, size_t *actual_len, int timeout)
{
	return -ENODEV;
}

static inline int hsic_sysmon_write(enum hsic_sysmon_device_id id,
				    const char *data, size_t len, int timeout)
{
	return -ENODEV;
}

#endif 

#endif 
