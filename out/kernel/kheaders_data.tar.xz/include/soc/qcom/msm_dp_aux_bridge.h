



#ifndef _MSM_DP_AUX_BRIDGE_H_
#define _MSM_DP_AUX_BRIDGE_H_

#include <linux/types.h>
#include <drm/drmP.h>
#include <drm/drm_dp_helper.h>


enum msm_dp_aux_bridge_flag {
	MSM_DP_AUX_BRIDGE_HPD = (1 << 0),
	MSM_DP_AUX_BRIDGE_MST = (1 << 1),
};


struct msm_dp_aux_bridge {
#ifdef CONFIG_OF
	struct device_node *of_node;
#endif
	void *dev_priv;
	u32 flag;
	void *mst_ctx;
	struct list_head head;

	
	int (*register_hpd)(struct msm_dp_aux_bridge *bridge,
			int (*hpd_cb)(void *, bool, bool), void *dev);

	
	ssize_t (*transfer)(struct msm_dp_aux_bridge *bridge,
			struct drm_dp_aux *drm_aux,
			struct drm_dp_aux_msg *msg);
};


int msm_dp_aux_add_bridge(struct msm_dp_aux_bridge *bridge);

#ifdef CONFIG_OF

struct msm_dp_aux_bridge *of_msm_dp_aux_find_bridge(struct device_node *np);
#endif

#endif 

