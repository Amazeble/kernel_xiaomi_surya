

#ifndef __ARCH_ARM_MSM_CLOCK_CONTROLLER_H
#define __ARCH_ARM_MSM_CLOCK_CONTROLLER_H

#include <linux/list.h>
#include <linux/clkdev.h>
#include <linux/of.h>
#include <linux/platform_device.h>

#define dt_err(np, fmt, ...) \
	pr_err("%s: " fmt, np->name, ##__VA_ARGS__)
#define dt_prop_err(np, str, fmt, ...) \
	dt_err(np, "%s: " fmt, str, ##__VA_ARGS__)


struct msmclk_parser {
	struct list_head list;
	char *compatible;
	void * (*parsedt)(struct device *dev, struct device_node *of);
};

#define MSMCLK_PARSER(fn, str, id) \
static struct msmclk_parser _msmclk_##fn##id = {		\
	.list = LIST_HEAD_INIT(_msmclk_##fn##id.list),		\
	.compatible = str,					\
	.parsedt = fn,						\
};								\
static int __init _msmclk_init_##fn##id(void)			\
{								\
	msmclk_parser_register(&_msmclk_##fn##id);		\
	return 0;						\
}								\
early_initcall(_msmclk_init_##fn##id)


#define HASHTABLE_SIZE 200
struct msmclk_data {
	void __iomem *base;
	struct device *dev;
	struct list_head list;
	struct hlist_head htable[HASHTABLE_SIZE];
	struct clk_lookup *clk_tbl;
	int clk_tbl_size;
	int max_clk_tbl_size;
};

#if defined(CONFIG_MSM_CLK_CONTROLLER_V2)


int of_property_count_phandles(struct device_node *np, char *propname);
int of_property_read_phandle_index(struct device_node *np, char *propname,
					int index, phandle *p);
void *msmclk_generic_clk_init(struct device *dev, struct device_node *np,
				struct clk *c);


void msmclk_parser_register(struct msmclk_parser *p);


void *msmclk_parse_phandle(struct device *dev, phandle key);

void *msmclk_lookup_phandle(struct device *dev, phandle key);

int __init msmclk_init(void);
#else

static inline int of_property_count_phandles(struct device_node *np,
			char *propname)
{
	return 0;
}

static inline int of_property_read_phandle_index(struct device_node *np,
			char *propname, int index, phandle *p)
{
	return 0;
}

static inline void *msmclk_generic_clk_init(struct device *dev,
				struct device_node *np, struct clk *c)
{
	return ERR_PTR(-EINVAL);
}

static inline void msmclk_parser_register(struct msmclk_parser *p) {};

static inline void *msmclk_parse_phandle(struct device *dev, phandle key)
{
	return ERR_PTR(-EINVAL);
}

static inline void *msmclk_lookup_phandle(struct device *dev, phandle key)
{
	return ERR_PTR(-EINVAL);
}

static inline int __init msmclk_init(void)
{
	return 0;
}

#endif 
#endif 
