

#ifndef __SDE_RECOVERY_MANAGER_H__
#define __SDE_RECOVERY_MANAGER_H__

#include <linux/list.h>
#include <linux/kthread.h>
#include <linux/platform_device.h>
#include <linux/kobject.h>
#include <drm/msm_drm.h>
#include <linux/slab.h>
#include <drm/drmP.h>


#define MAX_REC_NAME_LEN (16)


#define DRM_EVENT_SDE_UNDERRUN		0x80000008
#define DRM_EVENT_SDE_SMMUFAULT		0x80000009
#define DRM_EVENT_SDE_VSYNC_MISS	0x80000010
#define DRM_EVENT_RECOVERY_SUCCESS	0x80000011
#define DRM_EVENT_RECOVERY_FAILURE	0x80000012
#define DRM_EVENT_BRIDGE_ERROR		0x80000013


struct sde_recovery_client {
	char name[MAX_REC_NAME_LEN];
	int (*recovery_cb)(void *handle, u32 event, struct drm_crtc *crtc);
	u32 *events;
	int num_events;
	void *handle;
	struct list_head list;
};

#if IS_ENABLED(CONFIG_SDE_RECOVERY_MANAGER)


int sde_recovery_set_event(struct drm_device *dev, u32 event,
		struct drm_crtc *crtc);


int sde_recovery_client_register(struct drm_device *dev,
		struct sde_recovery_client *client);


int sde_recovery_client_unregister(struct drm_device *dev,
		struct sde_recovery_client *client);

#else

static inline int sde_recovery_set_event(struct drm_device *dev, u32 event,
		struct drm_crtc *crtc)
{
	return 0;
}
static inline int sde_recovery_client_register(struct drm_device *dev,
		struct sde_recovery_client *client)
{
	return 0;
}
static inline int sde_recovery_client_unregister(struct drm_device *dev,
		struct sde_recovery_client *client)
{
	return 0;
}

#endif

#endif 
