

#ifndef __SOC_QCOM_TCS_H__
#define __SOC_QCOM_TCS_H__

#define MAX_RPMH_PAYLOAD	16

struct tcs_cmd {
	u32 addr;		
	u32 data;		
	bool complete;		
};

enum rpmh_state {
	RPMH_SLEEP_STATE,	
	RPMH_WAKE_ONLY_STATE,	
	RPMH_ACTIVE_ONLY_STATE,	
	RPMH_AWAKE_STATE,	
};

struct tcs_mbox_msg {
	enum rpmh_state state;	
	bool is_complete;	
	bool is_read;		
	bool is_control;	
	bool invalidate;	
	u32 num_payload;	
	struct tcs_cmd *payload;
};

#endif 
