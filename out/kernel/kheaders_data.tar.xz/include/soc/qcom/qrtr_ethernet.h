

#ifndef _QRTR_ETHERNET_H
#define _QRTR_ETHERNET_H

#include <linux/skbuff.h>


struct qrtr_ethernet_cb_info {
	int (*eth_send)(struct sk_buff *skb);
};


struct eth_adapt_result {
	void *buf_addr;
	size_t bytes_xferd;
};

#if IS_ENABLED(CONFIG_QRTR_ETHERNET) || IS_ENABLED(CONFIG_QTI_QRTR_ETHERNET)
void qcom_ethernet_init_cb(struct qrtr_ethernet_cb_info *cbinfo);
void qcom_ethernet_qrtr_dl_cb(struct eth_adapt_result *eth_res);
void qcom_ethernet_qrtr_status_cb(unsigned int event);
#else
static inline void qcom_ethernet_init_cb(struct qrtr_ethernet_cb_info *cbinfo)
{
}
static inline void qcom_ethernet_qrtr_dl_cb(struct eth_adapt_result *eth_res) {}
static inline void qcom_ethernet_qrtr_status_cb(unsigned int event) {}
#endif 

#endif 
